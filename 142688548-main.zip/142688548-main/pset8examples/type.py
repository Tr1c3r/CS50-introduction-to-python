print(type([]))
