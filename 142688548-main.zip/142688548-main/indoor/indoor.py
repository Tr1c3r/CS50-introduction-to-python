palabra = str.lower(input("Introducir palabra en mayusculas "))
print (palabra)