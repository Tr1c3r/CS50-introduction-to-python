# First, the message
msg = input()

# Print the results
print(msg.replace(":(","🙁").replace(":)","🙂"))