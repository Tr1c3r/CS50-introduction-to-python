# Ask for the text
text = input("Write your text here: ")

# Print with modification
print (text.replace(" ","..."))