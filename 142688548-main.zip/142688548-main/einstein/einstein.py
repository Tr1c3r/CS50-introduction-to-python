# We declare the variables
csq = 3*10**8

# We ask for "m"
m = int(input("Write m in kg: "))

# At last, it shows the result
print(int(m*(csq**2)))
